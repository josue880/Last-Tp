interface Vehicule {
    void demarrer();
    void arreter();
    int getVitesseMax();
}
